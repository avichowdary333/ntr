# Android-SharedPrefs
A small demo project to show shared preferences in Android
